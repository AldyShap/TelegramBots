package com.javarush.telegram;

import com.javarush.telegram.ChatGPTService;
import com.javarush.telegram.DialogMode;
import com.javarush.telegram.MultiSessionTelegramBot;
import com.javarush.telegram.UserInfo;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.api.objects.*;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

import java.util.ArrayList;

public class TinderBoltApp extends MultiSessionTelegramBot {
    public static final String TELEGRAM_BOT_NAME = "Telegram_Bot_Name"; //TODO: добавь имя бота в кавычках
    public static final String TELEGRAM_BOT_TOKEN = "TelegramBotToken"; //TODO: добавь токен бота в кавычках
    public static final String OPEN_AI_TOKEN = "Open_AI_token"; // ADD here your open_ai_token
    private ChatGPTService chatGpt = new ChatGPTService(OPEN_AI_TOKEN);
    private DialogMode currentMode = null;
    private ArrayList<String> list = new ArrayList<>();
    private UserInfo me;
    private UserInfo mequiz;
    private int questionCount;
    private UserInfo she;

    public TinderBoltApp() {
        super(TELEGRAM_BOT_NAME, TELEGRAM_BOT_TOKEN);
    }

    @Override
    public void onUpdateEventReceived(Update update) {
        //TODO: основной функционал бота будем писать здесь
        // Main codes will be wirte here
        String message = getMessageText();

        showMainMenu("главное меню бота", "/start",
                "Общение с chatGPT", "/gpt",
                "генерация Tinder-профля \uD83D\uDE0E", "/profile",
                "сообщение для знакомства  \uD83E\uDD70", "/opener",
                "переписка от вашего имени \uD83D\uDE08", "/message",
                " переписка со звездами \uD83D\uDD25", "/date",
                "узнать какой вы человек \uD83D\uDCDD", "/quiz");

        //COMMAND /start
        if(message.equals("/start")) {
            currentMode = DialogMode.MAIN;
            sendPhotoMessage("main");
            String text = loadMessage("main");
            sendTextMessage(text);
            return;
        }

        //COMMAND GPT
        if(message.equals("/gpt")) {
            currentMode = DialogMode.GPT;
            sendPhotoMessage("gpt");
            String text = loadMessage("gpt");
            sendTextMessage(text);
        }

        if(currentMode == DialogMode.GPT && !isMessageCommand()) {
            String prompt = loadPrompt("gpt");
            String answer = chatGpt.sendMessage(prompt, message);
            sendTextMessage(answer);
            return;
        }
        // Command DATE
        if(message.equals("/date")) {
            currentMode = DialogMode.DATE;
            sendPhotoMessage("date");
            String text = loadMessage("date");
            sendTextButtonsMessage(text,
                    "Ариана Гранде", "date_grande","Марго Робби", "date_robbie","Райн Гослинг", "date_gosling","Зендей","date_zendaya","Том Харди", "date_hardy");
            return;
        }
        if(currentMode == DialogMode.DATE && !isMessageCommand()) {
            String query = getCallbackQueryButtonKey();
            if(query.startsWith("date_")) {
                sendPhotoMessage(query);
                sendTextMessage("Отличный выбор! Your goal is dating a girl/boy with using 5 questions");

                String promp = loadPrompt(query);
                chatGpt.setPrompt(promp);
                return;
            }
            if(query.equals("date_grande")) {
                sendPhotoMessage("date_grande");
                return;
            }
            if(query.equals("date_robbie")) {
                sendPhotoMessage("date_robbie");
                return;
            }
            if(query.equals("date_gosling")) {
                sendPhotoMessage("date_gosling");
                return;
            }
            if(query.equals("date_hardy")) {
                sendPhotoMessage("date_hardy");
                return;
            }

            Message msg = sendTextMessage("Подождите пару секунду, Девушка думает...");
            String answer = chatGpt.addMessage(message);
            updateTextMessage(msg, answer);
            return;
        }
        //Command MESSAGE
        if(message.equals("/message")) {
            currentMode = DialogMode.MESSAGE;
            sendPhotoMessage("message");
            sendTextButtonsMessage("Пишлите в чат вашу переписку",
                    "Следуйщее собщение", "message_next",
                             "Пригласить на свидание", "message_date");
            return;
        }
        if(currentMode == DialogMode.MESSAGE && !isMessageCommand()) {
            String query = getCallbackQueryButtonKey();

            if(query.startsWith("message_")) {
                String prompt = loadPrompt(query);
                String userChatHistory = String.join("\n\n", list);

                Message msg = sendTextMessage("Подождите пару секунд...");
                String answer = chatGpt.sendMessage(prompt, userChatHistory);
                updateTextMessage(msg, answer);

                return;
            }
//            String answer = chatGpt.sendMessage("Переписка", message);
//            sendTextMessage(answer);
            list.add(message);
            return;
        }
        //command Profile
        if(message.equals("/profile")) {
            currentMode = DialogMode.PROFILE;
            sendPhotoMessage("profile");

            me = new UserInfo();
            questionCount = 1;
            sendTextMessage("Сколько вам лет?");
            return;
        }
        if(currentMode == DialogMode.PROFILE && !isMessageCommand()) {
            switch (questionCount) {
                case 1:
                    me.age = message;
                    questionCount = 2;
                    sendTextMessage("Кем вы работаете?");
                    return;
                case 2:
                    me.occupation = message;

                    questionCount = 3;
                    sendTextMessage("У вас есть хобби?");
                    return;
                case 3:
                    me.hobby = message;
                    questionCount = 4;
                    sendTextMessage("Что вам не нравиться в людях?");
                    return;
                case 4:
                    me.annoys = message;
                    questionCount = 5;
                    sendTextMessage("Цель знакомство?");
                    return;
                case 5:
                    me.goals = message;
                    String aboutMyself = me.toString();
                    String prompt = loadPrompt("profile");
                    Message msg = sendTextMessage("Подождите пару секунд...");
                    String answer = chatGpt.sendMessage(prompt, aboutMyself);
                    updateTextMessage(msg, answer);
                    return;
            }

            return;
        }
        //COMMAND /opener
        if (message.equals("/opener")) {
            currentMode = DialogMode.OPENER;
            sendPhotoMessage("opener");
            she = new UserInfo();
            questionCount = 1;
            sendTextMessage("Имя девушки");
            return;
        }

        if(currentMode == DialogMode.OPENER && !isMessageCommand()) {
            switch(questionCount) {
                case 1:
                    she.name = message;
                    questionCount = 2;
                    sendTextMessage("Сколько ей лет?");
                    return;
                case 2:
                    she.age = message;

                    questionCount = 3;
                    sendTextMessage("Есть ли у нее хобби и какие?");
                    return;
                case 3:
                    she.hobby = message;
                    questionCount = 4;
                    sendTextMessage("Кем она работает?");
                    return;
                case 4:
                    she.occupation = message;
                    questionCount = 5;
                    sendTextMessage("Цель знакомство?");
                    return;
                case 5:
                    she.goals = message;
                    String aboutFriend = she.toString();
                    String prompt = loadPrompt("opener");
                    Message msg = sendTextMessage("Подождите пару секунд...");
                    String answer = chatGpt.sendMessage(prompt, aboutFriend);
                    updateTextMessage(msg, answer);
                    return;

            }
            return;

        }
        if(message.equals("/quiz")) {
            currentMode = DialogMode.QUIZ;
            String text = loadMessage("quiz");
            sendTextMessage(text);
            mequiz = new UserInfo();
            questionCount = 1;
            sendTextMessage("Ты больше любишь кошек или собак?");
            return;
        }
        if(currentMode == DialogMode.QUIZ && !isMessageCommand()) {

            switch (questionCount) {
                case 1:
                    mequiz.catordog = message;
                    questionCount = 2;
                    sendTextMessage("Что ты обычно делаешь в выходные?");
                    return;
                case 2:
                    mequiz.weekend = message;
                    questionCount = 3;
                    sendTextMessage("ЧТы больше интроверт или экстраверт?");
                    return;
                case 3:
                    mequiz.is_introvert_extrovert = message;
                    questionCount = 4;
                    sendTextMessage("О чём ты мечтаешь прямо сейчас?");
                    return;
                case 4:
                    mequiz.dreamnow = message;
                    String aboutFriend = mequiz.toString();
                    String prompt = loadPrompt("quiz");
                    Message msg = sendTextMessage("Подождите пару секунд...");
                    String answer = chatGpt.sendMessage(prompt, aboutFriend);
                    updateTextMessage(msg, answer);
                    return;
            }
            return;

        }


    }

    public static void main(String[] args) throws TelegramApiException {
        TelegramBotsApi telegramBotsApi = new TelegramBotsApi(DefaultBotSession.class);
        telegramBotsApi.registerBot(new TinderBoltApp());
    }
}
